CREATE TABLE cnt (
    cnt NUMBER
);
INSERT INTO cnt VALUES (0);
SELECT * FROM cnt;
UPDATE cnt SET cnt=11;
commit;



CREATE TABLE RECOMMEND_TB (
    recommend_ID VARCHAR2(50)
);
INSERT INTO recommend_tb VALUES ( 'ABC' );
INSERT INTO recommend_tb VALUES ( 'Alice' );
INSERT INTO recommend_tb VALUES ( 'Bob' );
commit;
SELECT * FROM recommend_tb;