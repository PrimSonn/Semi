package dto;

public class Recommend {
	String recommendId;

	public String getRecommendId() {
		return recommendId;
	}

	public void setRecommendId(String recommendId) {
		this.recommendId = recommendId;
	}

	// 데이터 확인용 toString
	@Override
	public String toString() {
		return "Recommend [recommendId="+recommendId+"]";
	}
}












