package countUp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CntDao {

	private final String url
		= "jdbc:oracle:thin:@localhost:1521:xe";
	private final String username = "scott";
	private final String password = "tiger";
	
	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	
	public CntDao() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					url,username, password);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public CntVo getCount() {
		String sql = "SELECT cnt FROM cnt";
		
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			
			rs.next();
			
			CntVo vo = new CntVo();
			vo.setCnt( rs.getInt("cnt") );
			
			return vo;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public void setCount(CntVo vo) {
		String sql = "UPDATE cnt SET cnt = ?";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, vo.getCnt());
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}















