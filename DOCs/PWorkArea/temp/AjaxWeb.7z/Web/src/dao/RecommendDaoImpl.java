package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.Recommend;

public class RecommendDaoImpl
	implements RecommendDao {

	private final String url
	= "jdbc:oracle:thin:@localhost:1521:xe";
private final String username = "scott";
private final String password = "tiger";
	
	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	
	public RecommendDaoImpl() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					url,username, password);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// 전체 추천인 수 반환
	public int getTotal() {
		String sql = "SELECT count(*) FROM recommend_tb";
		
		try {
			st = conn.createStatement();
			
			rs = st.executeQuery(sql);
			
			rs.next();
			
			return rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return -1;
	}
	
	// 이미 추천한 id인지 확인
	public boolean check(Recommend r) {
		String sql = "SELECT count(*) FROM recommend_tb"
				+ " WHERE recommend_ID = ?";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, r.getRecommendId());
			
			rs = pst.executeQuery();
			rs.next();
			int res = rs.getInt(1);
			
//			System.out.println("COUNT(*) : " + res);
			
			if( res > 0 ) {
				// 추천 기록이 있는 ID
				return true;
			} else {
				// 추천 기록이 없는 ID
				return false;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	// 추천인 등록
	public void insert(Recommend r) {
		String sql = 
				"INSERT INTO recommend_tb " + 
				"VALUES ( ? )";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, r.getRecommendId());
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// 추천인 삭제
	public void delete(Recommend r) {
		String sql = "DELETE recommend_tb " +
					"WHERE recommend_ID = (?)";
		
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, r.getRecommendId());
			
			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List getList() {
		String sql = "SELECT recommend_id "
				+ "FROM recommend_tb "
				+ "ORDER BY recommend_id";
		
		List<Recommend> list = new ArrayList<>();
		
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while( rs.next() ) {
				Recommend r = new Recommend();
				r.setRecommendId(rs.getString("recommend_id"));
				
				list.add(r);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
}













