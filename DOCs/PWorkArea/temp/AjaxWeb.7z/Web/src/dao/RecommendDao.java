package dao;

import java.util.List;

import dto.Recommend;

public interface RecommendDao {

	// 전체 추천인 수 반환
	public int getTotal();
	
	// 이미 추천한 id인지 확인
	public boolean check(Recommend r);

	// 추천인 등록
	public void insert(Recommend r);
	
	// 추천인 삭제
	public void delete(Recommend r);

	// 추천인 목록 조회
	public List getList();
	
}















