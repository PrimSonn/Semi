package service;

import java.util.List;

import dao.RecommendDao;
import dao.RecommendDaoImpl;
import dto.Recommend;

public class RecommendServiceImpl
	implements RecommendService {

	private RecommendDao dao = new RecommendDaoImpl();

	//SELECT count(*) 결과 반환
	@Override
	public int getTotal() {
		return dao.getTotal();
	}
	
	// user의 ID가 존재하는지 체크
	@Override
	public void check(Recommend user) {
		// true - 이미추천함, false - 아직추천안함
		if( dao.check(user) ) {
			dao.delete(user);
		} else {
			dao.insert(user);
		}
	}

	@Override
	public List getList() {
		return dao.getList();
//		
//		List list = dao.getList();
//		if ( list != null ) {
//			return list;
//		} else {
//			return null;
//		}
	}
}














