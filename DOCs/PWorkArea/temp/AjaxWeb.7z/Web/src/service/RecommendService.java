package service;

import java.util.List;

import dto.Recommend;

public interface RecommendService {

	//SELECT count(*) 결과 반환
	public int getTotal(); 
	
	// user의 ID가 존재하는지 체크
	public void check(Recommend user);
	
	// 전체 추천인 목록 반환
	public List getList();
	
}















