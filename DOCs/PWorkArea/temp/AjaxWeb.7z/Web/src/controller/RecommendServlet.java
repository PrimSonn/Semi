package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Recommend;
import service.RecommendService;
import service.RecommendServiceImpl;

@WebServlet("/recommend/main.do")
public class RecommendServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private RecommendService recommendService = new RecommendServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ----- 전체 추천수 view에 전달하기 -----
		int total = recommendService.getTotal();
		request.setAttribute("total", total);
		// -----------------------------------
		
		// -----전체 추천수 view에 전달하기 ----- 
		List<Recommend> list = null;
		list = recommendService.getList();
		request.setAttribute("list", list);
		// -------------------------
		
		// view forward
		RequestDispatcher rd = null;
		rd = request.getRequestDispatcher(
				"/view/recommend/main.jsp");
		rd.forward(request, response);
		
	}
}












