package dto;

public class Recommend {
	
	String recommendId;
	public String getRecommendId() {
		return recommendId;
	}public void setRecommendId(String recommendId) {
		this.recommendId = recommendId;
	}
}
