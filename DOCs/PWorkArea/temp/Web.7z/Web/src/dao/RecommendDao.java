package dao;

import dto.Recommend;

public interface RecommendDao {
	public int getTotal();
	public boolean check(Recommend r);
	public void insert(Recommend r);
	public void delete(Recommend r);
}
