package countUp;

public class CntVo {
	
	private int cnt;
	
	public int getCnt() {
		return cnt;
	}public void setCnt(int cnt) {
		this.cnt = cnt;
	}

}
