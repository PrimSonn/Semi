package service;

import dao.RecommendDao;
import dao.RecommendDaoImpl;
import dto.Recommend;

public class RecommendServiceimpl implements RecommendService{

	@Override
	public int getTotal() {
		
		RecommendDao dao = new RecommendDaoImpl();
		
		return dao.getTotal();
	}
	@Override
	public void check(Recommend user) {
		RecommendDao dao = new RecommendDaoImpl();
		if( dao.check(user) ) {
			dao.delete(user);
		}else {
			dao.insert(user);
		}
	}
}
