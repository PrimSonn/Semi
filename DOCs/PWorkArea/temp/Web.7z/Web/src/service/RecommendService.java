package service;

import dto.Recommend;

public interface RecommendService {
	public int getTotal();
	public void check(Recommend user);
}
