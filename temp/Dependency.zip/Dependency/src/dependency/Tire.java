package dependency;

public interface Tire {

	default String getProduct() {
		return "No Tire";
	};
}
