package dependency;

public class Car {
	private Tire tire;
	
	public Car() {
		tire = new GoldenTire();
	}
	
	public String getTire() {
		return tire.getProduct() + " added!";
	}
	
}
