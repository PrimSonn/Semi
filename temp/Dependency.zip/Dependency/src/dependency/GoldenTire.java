package dependency;

public class GoldenTire implements Tire{

	@Override
	public String getProduct() {
		return "Golden Tire";
	}

}
