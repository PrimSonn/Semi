package dependency;

public class SilverTire implements Tire{

	@Override
	public String getProduct() {
		return "Silver TIre";
	}

}
