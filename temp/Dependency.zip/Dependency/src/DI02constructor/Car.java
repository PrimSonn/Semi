package DI02constructor;

import dependency.Tire;

public class Car {
	private Tire tire;
	
	public Car() {
		this.tire = new Tire() {
			
		};
	}
	
	public Car(Tire tire) {
		this.tire = tire;
	}
	
	public String getTire() {
		return tire.getProduct() + " added!";
	}

	public void setTire(Tire tire) {
		this.tire = tire;
	}
}
