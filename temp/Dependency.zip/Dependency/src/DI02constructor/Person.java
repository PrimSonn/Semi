package DI02constructor;

import dependency.GoldenTire;
import dependency.SilverTire;

public class Person {
	public static void main(String[] args) {
		
		Car car = new Car(new SilverTire());
		car.setTire(new GoldenTire());
		System.out.println(car.getTire());
		System.out.println(new Car().getTire());
	}
}
