package DI01constructor;

import dependency.Tire;

public class Car {
	private Tire tire;
	
	public Car(Tire tire) {
		this.tire = tire;
	}
	
	public String getTire() {
		return tire.getProduct() + " added!";
	}
}
