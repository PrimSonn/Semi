package mvc.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import mvc.dao.BoardDao;
import mvc.dao.CommentDao;
import mvc.dao.RecommendDao;
import mvc.dto.Board;
import mvc.dto.BoardFile;
import mvc.dto.Comment;
import mvc.util.Paging;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired ServletContext context;

	@Autowired BoardDao boardDao;
	@Autowired RecommendDao recommendDao;
	@Autowired CommentDao commentDao;
	
	@Override
	public List getList() {
		return boardDao.selectAll();
	}

	@Override
	public int getTotal() {
		return boardDao.countAll();
	}

	@Override
	public int getTotal(Paging search) {
		return boardDao.countSearch(search);
	}

	@Override
	public List getPagingList(Paging paging) {
		return boardDao.selectPage(paging);
	}

	@Override
	public List getSearchPagingList(Paging search) {
		return boardDao.selectPageSearch(search);
	}
	
	@Override
	public void write(Board board) {
		boardDao.write(board);
		
		MultipartFile file = board.getFileup();
		if(file != null && !file.isEmpty()) {
			// 파일 업로드
			String path = context.getRealPath("upload");
			String filename = file.getOriginalFilename()+"_"+UUID.randomUUID().toString().split("-")[0];
			File dest = new File(path, filename);

			try {
				file.transferTo(dest);
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			// DB 기록
			BoardFile boardFile = new BoardFile();
			boardFile.setBoardno(board.getBoardno());
			boardFile.setOriginal_filename(file.getOriginalFilename());
			boardFile.setStored_filename(filename);
			
			boardDao.insertFile(boardFile);
		}
	}

	@Override
	public Board boardView(Board viewBoard) {
		
		boardDao.updateHit(viewBoard);
		
		return boardDao.selectBoardByBoardNo(viewBoard);
	}

	@Override
	public void update(Board board) {
		boardDao.update(board);
	}

	@Override
	public void delete(Board board) {
		boardDao.delete(board);
		boardDao.deleteFile(board);
	}

	@Override
	public boolean recommendCheck(Board board) {
		
		if( recommendDao.selectCountRecommend(board) > 0 ) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override	
	public boolean recommend(Board board) {
		if( recommendCheck(board) ) {
			recommendDao.deleteRecommend(board);
			return false;
		} else {
			recommendDao.insertRecommend(board);
			return true;
		}
		
	}
	
	@Override
	public int getRecommend(Board board) {
		return recommendDao.selectTotalRecommend(board);
	}

	@Override
	public void insertComment(Comment comment) {
		commentDao.insertComment(comment);
	}

	@Override
	public List getCommentList(Board board) {
		return commentDao.selectComment(board);
	}

	@Override
	public boolean deleteComment(Comment comment) {
		commentDao.deleteComment(comment); 
		
		if( commentDao.countComment(comment) > 0 ) {
			return false;
		} else {
			return true;
		}
	}
	
	@Override
	public void boardListDelete(String names) {
		boardDao.deleteBoardList(names);
		boardDao.deleteBoardFileList(names);
	}

	@Override
	public BoardFile getFileup(Board viewBoard) {
		return boardDao.getFile(viewBoard);
	}

	@Override
	public String getStoredFileName(BoardFile boardFile) {
		return boardDao.getStoredFilename(boardFile);
	}
	
}













