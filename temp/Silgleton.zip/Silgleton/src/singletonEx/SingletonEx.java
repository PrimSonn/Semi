package singletonEx;

import singleton.Single01;
import singleton.Single02;
import singleton.Single03;

public class SingletonEx {
	
	public static void main(String[] args) {
		
		Single01 s1 = Single01.getinstance();
		Single01 s2 = Single01.getinstance();
		System.out.println("s1==s2? "+ (s1==s2));
		
//		Single01 s3 = new Single01();
//		System.out.println("s1==s3?"+ (s1==s3));	//--false
		
		
		Single02 s3 = Single02.getInstance();
		Single02 s4 = Single02.getInstance();
		System.out.println("s3==s4? "+(s3==s4));
		
		
		Single03 s5 = Single03.getInstance();
		Single03 s6 = Single03.getInstance();
		System.out.println("s5==s6? "+(s5==s6));
		
		
	}

}
