package singleton;

public class Single02 {
	//comes with an exception handling.
	
	
	private static Single02 instance;
	private Single02() {}
	
	static {
		try {
			instance = new Single02();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Single02 getInstance() {
		return instance;
	}
}
