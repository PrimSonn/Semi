package singleton;

public class Single04 {
	
	private static Single04 instance;
	private Single04() {}
	
	public static synchronized Single04 getInstance() {
		
		if(instance ==null) {
			try {
				instance = new Single04();
			}catch(Exception e) {
				
			}
		}
		return instance;
	}
}