package singleton;

public class Single03 {
	
	private static Single03 instance;
	private Single03() {}
	
	public static Single03 getInstance() {
		
		if(instance ==null) {
			try {
				instance = new Single03();
			}catch(Exception e) {
				
			}
		}
		return instance;
	}
}