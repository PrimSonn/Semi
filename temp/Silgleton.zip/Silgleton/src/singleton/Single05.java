package singleton;

public class Single05 {
	
	private static class Singleton{
		private static final Single05 instance = new Single05();
	}
	
	private Single05() {}
	
	public static Single05 getInstance() {
		return Singleton.instance;
	}
	
}