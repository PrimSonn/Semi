package singleton;

public class Single01 {
	// instantiated when not used
	// no exception while instantiating

	private static Single01 instance = new Single01();
	
	private Single01() {
	}
	
	public static Single01 getinstance() {
		return instance;
	}
}
