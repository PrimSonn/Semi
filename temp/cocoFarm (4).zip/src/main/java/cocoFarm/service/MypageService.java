package cocoFarm.service;

public interface MypageService {
	
}
